#include <iostream>

int main()
{
    /*
    //we use do while loops to happen atleast once
    std::string password = "hellosolta357";
    std::string guess;
    do
    {
        std::cout << "Guess the password!! ";
        std::cin >> guess;
    } while (guess != password);
    */

     std::string password = "hellosolta357";
     std::string guess;

     std::cout << "Guess the password:?? ";
     std::cin >> guess;
     while(guess != password)
     {
          std::cout << "Guess the password:- ";
          std::cin >> guess;

     }
}

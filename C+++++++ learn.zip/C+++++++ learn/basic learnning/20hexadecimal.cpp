#include <iostream>
#include <string>
using std::string;
using std::cout; 
using std::cin;
using std::endl;
int main()
// in decimal 24 means 4 times 1 and 2 times 10
//in hexadecimal 24 = 18 which is 8 times one and 1 times 16
// in octals 24 = 0030 which means three times 8
{
    int hextod = 0x186;
    int decimal = 48;
    int number = 47; //decimal system
    int hexdec = 0x63; // hexadecimal which means 16 times 6 and 3 times 1
    int octdec = 030; // three times 8
    int newnum = 63;
    int tryconv = 58;
    cout << hextod << endl;
    cout << decimal << endl;
    cout << number << endl;
    cout << hexdec << endl;
    cout << octdec << endl;
    cout << std::hex << number << endl; // e in the output is 14 and 1 ia 1 times 16; 14 + 16 = 30 output 1e
    cout << std::oct << number << endl; // output 36 here 3 times 8 plus 6 equals 30
    cout << std::hex << decimal << endl; // 2f f is 15, 15 times 1 and 2 times 16
    cout << std::oct << decimal <<endl; // 5 times 8 + 7 57
    cout << std::hex << newnum <<endl;
    cout << std::oct << newnum <<endl;
    cout << std::hex << tryconv <<endl;
    cout << std::oct << tryconv <<endl; // 3f means f is 14 so 15 times 1 + 3 times 16 = 63 in decimal¥
}   
#include <iostream>
#include <cmath>
using std::cout;
using std::cin;
int main()
{
    cout << sqrt(25) <<std::endl;
    cout << sqrt(-25) << std::endl; //output nan means imaginary number
    cout << pow(9,9999) << std::endl; //inf is infinity
    cout << NAN << std::endl;
    cout << INFINITY << std::endl;
    cout << -INFINITY << std::endl;
    cout << remainder(10, 3) << std::endl; // 10/3 rem is 1
    cout << 10 % 3 << std::endl; // % is modulus operator
    //cout << 10 % 3.25 << std::endl;
    cout << remainder(10, 3.25) << std::endl;
    cout << fmod( 10, 3.25) << std::endl; // litte diff between fmod and remainder
    cout <<fmax( 19, 4) << std::endl;
    cout << fmin(32, 6) << std::endl;
    cout << ceil(fmin( 10, 3.25)) << std::endl; // round of fmin to upper lvl
    cout << floor(fmin( 10, 3.25)) << std::endl; // round of fmin to lower lvl
    cout << ceil(fmax( 10.3, 3.25)) << std::endl;
    cout << trunc(fmax( 10.3, 3.25)) << std::endl; // floor and trunc are similar
    // the different between floor and trunc is on negative value number
    cout << floor(-1.5) << std::endl;
    cout << trunc(-1.5) << std::endl;
    cout << round(2.8) << std::endl;
    cout << round(-2.8) << std::endl;
    cout << nearbyint(8.4) << std::endl;
    cout << nearbyint(8.6) << std::endl;
}
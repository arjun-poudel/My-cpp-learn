// ternary operator
// it has three operants
#include <iostream>
#include <string>

int main()
{
    int answer = 16;
    std::cout << "Guess the number: ";
    int guess;
    std::cin >> guess;
    int points = guess == answer ? 10 : 0;
    guess == answer ? std::cout << "Good job! " : std::cout << "Bad job! ";
    // this is the syntax of conditional operator
    // some expression the question mark the value if true colun and the value if false
    /*
     int answer = 12;
     std::cout << "Guess the number: ";
     int guess;
     std::cin >> guess;
     int points = guess == answer ? 10 : 0;
     /*
     int points;
     if(guess == answer)
     {
        points = 10;
     }
     */
     std::cout << "your score is " << points << std::endl;
}
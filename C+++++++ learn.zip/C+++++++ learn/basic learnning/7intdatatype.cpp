
//int datatype detail

#include <iostream>
#include <climits>
using std::cout;
int main()
{
    short a; // least 16 bits
    int b; // least 32 bits
    long c; // least 64 bits
    long long d; // least 64 bits
    // least here implies can go prity high
    //short <= int <= long <= long long
    unsigned short aa;
    unsigned int bb;
    unsigned long cc;
    unsigned long long dd;
    //unsigned ones only allows positive values
    cout << sizeof(int) << std::endl;
    cout << SHRT_MAX << std::endl;
    cout << SHRT_MIN << std::endl;
    cout << USHRT_MAX << std::endl;
    cout << ULONG_MAX << std::endl;
    cout << LLONG_MIN << std::endl;
    cout << ULLONG_MAX << std::endl;
    cout << INT_MAX << std::endl;
    cout <<sizeof(long) << std::endl;
}
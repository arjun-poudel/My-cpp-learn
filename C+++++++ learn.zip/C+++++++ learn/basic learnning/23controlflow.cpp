// branching and looping
// brinching is to do contitions and branch our application to so something according to our result
// loopoing is to make something for repetation of code for certain number of time
// branching contains if statment and switch statement
// looping contains while, for and do - while loops
if (exp) --- T/F
{
   //statement // code
} else (next exp)
{
    //do this statement if false //if we use else.
}
// if true it will esses inside curly bracket ottherwise jump out of statment.
// if true excute it otherwise skip it.
// we can do without else it means do something  if true or do nothing if false
// but if we use "else" do something in both cases
// the third one is "if else if()"
if(exp1)
{
    //do something stat/code
}
else if(exp2)
{
    //or do this
}
else(exp3)
{
    //code
}
// if first true we do that and if first false we do second
// but if both 1st and 2nd are false we go third one
             // SWITCH STATEMENT
 //            
 switch (age)
 {
    case 17: //if age is 17 we do this
    //code
    break;
    case 18: // if age is 18 then we do this
    //code
    break;
    default: // all the ages between 17 and 18 are default
    //code //default is kinda like catch all
    break;
 }

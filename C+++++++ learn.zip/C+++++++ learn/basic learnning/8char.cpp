#include <iostream>
using std::cout;
using std::cin;
int main()
{
    char x = 'A'; //double qoutlts are used for strings and
    cout << (int) x << std::endl; // interpreting x as an integer
    char y = 'B';
    cout << y << std::endl;
    cout << (int) y << std::endl; //ASCII Table and Description
    char z = 68;
    cout <<  z << std::endl;
    cout << (int) z << std::endl;
    unsigned char p =129;
    cout << (int) p << std::endl;
    cout << p << std::endl;
    signed char q = 130;
    cout << q << std::endl;
    cout << (int) q << std::endl;
    char r = 129;
    cout << r << std::endl;
    cout << (int) r << std::endl;

}
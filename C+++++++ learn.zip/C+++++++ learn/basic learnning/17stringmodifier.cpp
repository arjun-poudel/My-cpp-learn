#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::string;
int main()
{
    string greeting = "Hellow";
    greeting += " there are"; // += and .append work same
    greeting.append(" many people");
    greeting.insert(3,"");
    greeting.erase(2, 4);
    greeting.erase(greeting.length() - 1); // to erage from last
    greeting.pop_back(); // same as line 13
    greeting.replace(4, 9, "Heaven"); //first argument is starting index and second one is the length
    cout << greeting << std::endl;
    cout << greeting.length() << std::endl;
    cout << greeting.size() << std::endl;
}
#include <iostream>
#include <cmath>
using std::cout;
using std::cin;
int main()
{
    cout << pow(3, 4);
}
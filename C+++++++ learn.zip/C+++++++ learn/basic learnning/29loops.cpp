#include <iostream>
#include <string>
// the simple loop that we know is while loop
// other two loops are do while loop and the for loop

int main()
{
    for (int i = 0; i < 15; i++) // initialization, comparision and the update i++.
    {
        std::cout << i << std::endl;
    }



    for (int i = 9; i > 0; i--)
    {
        std::cout << i << std::endl;
    }
    
    // int factorial = 6;
    int fact = 8;
    int factorial = fact;
    for(int i = factorial - 1; i > 0; i--)
    {
        factorial = factorial * i;
        // std::cout << "factorial: " << factorial << std::endl; // this code inside shows each step of multiplication
        //std::cout << "factorial of " << fact << " is  " << factorial << std::endl;
    }
     std::cout << "factorial of " << fact << " is  " << factorial << std::endl;
     // std::cout << "factorial: " << factorial << std::endl; // "factorial: " here it shows output as factorial: 720
     // this code outside gives total values of factorial.
   
}
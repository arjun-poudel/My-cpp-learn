#include <iostream>
using std::cout;
using std::cin;
using namespace std;
//bool data types is just true and false
//1 is true and 0 is false in general
// 0 is false other all are considered as true even negative
int main()
{
    bool chatpate_is_good = true;
    bool pizza_is_bad = false;
    bool someone_is_rugrug = -12;  
    bool buda_lai_jheu_laxa =0;
    bool found = false;
    bool lost = true;
    cout << chatpate_is_good << std::endl;
    cout << pizza_is_bad << std::endl;
    cout << std::boolalpha << someone_is_rugrug << std::endl;
    cout << buda_lai_jheu_laxa << std::endl;
    cout << found << std::endl;
    cout << lost << std::endl;

}
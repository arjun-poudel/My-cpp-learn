#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::string;
int main()
{
    string greeting; // empty string we need to write in output
    cin >> greeting;
    string remaining;
    cin >> remaining;
    string tesro_sabda;
    cin >> tesro_sabda;
    cout << tesro_sabda << std::endl;
    cout << remaining << std::endl;
    cout << greeting << std::endl;
    cout << greeting + remaining + tesro_sabda << std::endl;
    string full_sentense_with_space;
    getline(cin, full_sentense_with_space); // getline gives full string
    cout << full_sentense_with_space << std::endl;
    // cin.getline() need to research.
}
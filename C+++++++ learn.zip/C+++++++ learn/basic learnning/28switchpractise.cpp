#include <iostream>
#include <string>
int main()
{
    enum season{summer, spring, autum, winter};
    int season;
    std::cout << "Choose the season";
    std::cin >> season;
    switch(season)
    {
        case 1:
             std::cout << "Go for swimming!!\n";
             break;
        case 2:
             std::cout << "Let`s do barbique!!\n";
             break;
        case 3:
             std::cout << "Feel the sunshine!!\n"; 
            break;
        case 4:
            std::cout << "Stay warm!!\n";   
            break;
    }
}
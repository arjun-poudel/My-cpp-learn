#include <iostream>
#include <string>

int main()
{
    int age;
    std::cout << "What is your age?";
    std::cin >> age;
    switch(age)
    {
        case 13:
        case 14:
            std::cout << "Your age is 13 or 14\n";
            break;
        case 15:
            std::cout << "You are 15\n";
            break;
        default:
            std::cout << "Catch all\n";
            break;
    }
    return 0;
}
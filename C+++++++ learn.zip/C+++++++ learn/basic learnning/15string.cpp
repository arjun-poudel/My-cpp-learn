#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::string;
int main()
{
    string greeting = "hellow";
    cout << greeting << std::endl; //empty sting 
    string scold = "jatha";
    cout << scold[5] << std::endl; // 4th character from the character
    cout << scold + "  gandkas" << std::endl;
    cout << scold << std::endl; // to make whole word output
    string grocery = "green";
    string complete = grocery + " chilli";
    complete += " !";
    cout << complete << std::endl;
    cout << complete.length() << std::endl;
    //method == member function == functions attached to objects

    char name[] = "Caleb;"; // c string == array of characters "Caleb\0"
    //name = "tacobell";
    complete = "Go  away jjatha";
    cin >> greeting;
    cout << greeting << std::endl; // it doesnot give output after space
}

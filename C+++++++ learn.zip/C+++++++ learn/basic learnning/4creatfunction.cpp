#include <iostream>
#include <cmath> //pow function is from cmath so we include

using std::cout;
using std::cin;
double power(double base, int exponent) // declaring and defining
{
    return 8;
}

int main()

{
    int base, exponent;
    cout << "What is the base?: ";
    cin >> base;
    cout << "Wtat is the exponent?";
    cin >> exponent;
    double myPower = power(base, exponent); 
    //calling the function double power = pow(base, exponent);
    cout << myPower << std::endl;
}
#include <iostream>
#include <string>
int main()
{
     int factorial = 5;
     int k = factorial - 1; // if we dont do -1 it will start 5*5*4...
     while(k >= 1)
     {
        factorial *= k;
        k--;
     }
     std::cout << factorial << std::endl;
     




     int i = 15;
     while(i > 0)
     {
        std::cout << i << std::endl;
        i--;
     }


     /* // vertical view
     int j = 16;
     while(j < 25)
     {
        std::cout << j << std::endl;
        j++;
     }
     */
     
     
     //horizontal view of output
     int j = 16;
     while(j < 25)
     {
        std::cout << j << "\t";
        j++;
     }
     std::cout << "\n";

     
     for(int i = 15; i > 0; i--)
     {
        std::cout << i << std::endl;
     }
     


    
    
    
     /*
     int fact = 8;
     int factorial = fact;
     for(int i = factorial - 1; i > 0; i--)
     {
        factorial = factorial * i;
     }
     std::cout << "factorial of " << fact << " is  " << factorial << std::endl;
     */ 
}
#include <iostream>
#include <string>

int main()
{
    enum season{summer, spring, autum, winter};
    season now = winter;
    season next = summer;
    season nice = spring;
    season good = autum;
   
    // switch(now)
    //switch(next)
    // switch(nice)
    switch(good)
    {
         case summer:
             std::cout << "Go for swimming!!\n";
             break;
        case spring:
             std::cout << "Let`s do barbique!!\n";
             break;
        case autum:
             std::cout << "Feel the sunshine!!\n"; 
            break;
        case winter:
            std::cout << "Stay warm!!\n";   
            break;
    }
}
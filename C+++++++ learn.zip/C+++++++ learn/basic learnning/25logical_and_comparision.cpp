#include <iostream>
#include <string>

int main()
{
    std::string name_answer = "Lina";
    int age_answer = 32;
    std::string name_guess; // this input is to guess name
    std::cout << "Guess my name!";
    std::cin >> name_guess;

    int age_guess;
    std::cout << "Guess my age!";
    std::cin >> age_guess; // this input is to guess age


    //if(guess == answer && age_guess == age_answer) // && is and operator both must be true
    //if(name_guess == name_answer || age_guess== age_answer ) // || is or if one of them is true
    // if(!(name_guess == name_answer)) // null operator if both false statement also cout
    // if(name_guess != name_answer) // != is not equal to which means both statement false but return
    // if we want and operator in another way
     //if(name_guess == name_answer) // this should be true
     //{
         //if(age_guess == age_answer)
         //{
              //std::cout << "You are right!\n";
         //}
     //}
     // or operator in another way
    if((name_guess == name_answer)) // and this should be true
    {
         std::cout << "You are right!\n";
    }
    else if(age_guess == age_answer)
    {
        std::cout << "You are right!\n";
    }
    
} 


// logical operator
// && and || or and ! null 

// comparision operator
// == equal to ! not euqual to <  > <= >=
//here we are talking about literal constant
#include <iostream>
#include <string>
using std::cout;
using std::cin;
int main()
{
    auto x = 5U; // U for unsigned
    auto y = 5UL; // unsigned long
    auto z = 5ULL; // unsined long long
    auto p = 5.0F; // to specify this is a float
    auto q = 5.0; // its a double
    auto r = 5.L;// its a long double the actual value zero not necessary to mention
    //x = "what is a string";
}
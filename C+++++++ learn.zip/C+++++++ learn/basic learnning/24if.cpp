#include <iostream>
int main()
{
    std::cout << "How old are you??";
    int age;
    std::cin >> age;
    //std::cout << "Hou old are you?";
    //int age = 21;
    //if(age > 23)
    if(age < 14) // 21 is bigger then 15 so true
    {
       
        std::cout << "You are not old enough\n";
        //return -1; // it doesnot allows anything to do after this. it means do somethif if true or nothing if false
    }
    else if(age > 16 && age < 21) 
    {
        std::cout << "You are around 19 !!wow!!\n";
    }
    else
    {
        std::cout << "False\n";
    }
    
    return 0;
}
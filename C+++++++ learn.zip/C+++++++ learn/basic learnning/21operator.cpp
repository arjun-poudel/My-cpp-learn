#include <iostream>
using std::cout;
using std::endl;
int main()
{
    int x = 5+5;
    int y = 5-5;
    int z = 5*5;
    int a = 10/4;
    int b = 10./4;
    double c = 10./4;
    int d = 10%4;
    int e = 10%4; // keep the remainder only
    double f = 10 + (5/3);
    cout << x << endl;
    cout << y << endl;
    cout << z << endl;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cout << d << endl;
    cout << e << endl;
    cout << f << endl;

}
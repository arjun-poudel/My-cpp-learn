#include <iostream>
#include <float.h> // this file going to make how many significant degits
using std::cout;
using std::cin;
int main()
{
    int cents = 100;
    float a = 10.0/3; 
    // it has the least number of significant digits that we can trust
    // it means there is no 3333 after some significant number
    a = a * 10000000000;
    double b = 20.0/3;
    b = b * 1000000000000000;
    long double c = 20.0/7;
    c = c * 100000000000000;
    cout << std::fixed << a << std::endl;
    cout << std::fixed << b << std::endl;
    cout << std::fixed << c << std::endl;
    cout << FLT_DIG << std::endl; // in running we get 6 it means we trust upto 6 digits
    // 7th here in output still 3 but really not trusty after 6th digits
    cout << DBL_DIG << std::endl; //this means double allows 15 trustable significant digits
    cout << LDBL_DIG << std::endl; // 18 significant digits

}
// contant const, macro and enum
#include <iostream>
using std::cout;
using std::cin;
#define y 10 // another way to create constant
int main()
{
    //int x = 5; // here the value 5 is a literal constant
    // this is not we are talking about here rather we are talking about symbolic constant.
    // it is just to prefix a variable with keywork const
    const int x = 5; // it is read only variable as we do x = 10; doesnt gonna run
    cout << x+y << std::endl;

    //enum (z = 15)  //not working ??
    //cout << x * z << std::endl;

}
#include <iostream>
#include <cmath> //pow function is from cmath so we include

using std::cout;
using std::cin;
//double power(double, int); // declaration
double power(double base, int exponent) //declaration and definition
// we can do declaration in top and define in down just both in top is best
{
    double result = 2;
    for(int i=0; i < exponent; i++)
    {
        result = result * base;
    }
    return result;
}
int main()

{
    int base, exponent;
    cout << "What is the base?: ";
    cin >> base;
    cout << "Wtat is the exponent?";
    cin >> exponent;
    double myPower = power(base, exponent); //calling the function double power = pow(base, exponent);
    cout << myPower << std::endl;
}
//this function have return value result and that of type double5
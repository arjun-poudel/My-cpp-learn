#include <iostream>
using std::cout;
using std::cin;
int main()
{
    // if we are going char for the number we can go for 127 max
    // if we are using char for character we definetely limit to any of the standard character that are in the ascii table
    char x = 'A'; //double qoutlts are used for strings and
    char y = 'B'; // char by default in our case is signed qoults
    char z = 68;
    unsigned char p =129;
    signed char q = 129; //signed means allows negative number
    char r = 129;
    cout << (int) x << std::endl; // interpreting x as an integer
    cout << y << std::endl;
    cout << (int) y << std::endl; //ASCII Table and Description
    cout << z << std::endl;
    cout << (int) z << std::endl;
    cout << (int) p << std::endl;
    cout << p << std::endl;
    cout << q << std::endl;
    cout << (int) q << std::endl;
    cout << r << std::endl;
    cout << (int) r << std::endl;
}
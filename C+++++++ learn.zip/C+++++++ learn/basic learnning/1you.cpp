#include <iostream>
using std::cout; //using directive
using std::cin;
int main() //main function
{
    int pieces;
    cout << "Dear Lina, how many pieces of cake you want to eat?:";
    cin >> pieces;
    cout << "Enjoy your "<<pieces << " pieces of cake."<<std::endl;
}

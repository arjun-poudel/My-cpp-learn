// break and continue are two important keywords in loop
#include <iostream> 
#include <string>

int main()
{
    std::string sentence = "Hello i am in oodi now.!!";
    for(int i =0; i < sentence.size(); i++)
    {
        /*
        std::cout << sentence[i] << std::endl;
        if(sentence[i] == 'o')
        {
            std::cout << "found o\n";
            break; //after finding particular letter it breaks 
        }
        */
        if(sentence[i] == 'o')
        {
            continue; // this skip choosen letter and display other
        }
        std::cout << sentence[i] << std::endl;
    }
    std::cout << "nice!!\n";

}
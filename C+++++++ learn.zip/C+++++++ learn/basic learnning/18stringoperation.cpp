#include<iostream>
#include<string>
using std::cout;
using std::cin;
using std::string;
int main()
{
    string greeting = "what the hell?";
    greeting.replace(9, 2, "****"); // here 9 in index number 2 is replace 9th and 10 th characher with ****
    greeting.replace(7, 1, " satti-patti "); // the ko 'e' lai replace garnu paryo
    greeting.replace(6, 3, "baal_ho"); // 6th index the ko t ho thes paxi ko 3 ta chartr ko thau ma replace
    greeting.replace(greeting.find("hell"), 6, "****");
    greeting.replace(greeting.find("the"), 1, "****");
    greeting.replace(greeting.find("hell"), 6, "****");
    cout << greeting << std::endl;
    string conversation = "what are you doing?";
    cout << conversation.substr(3, 3) << std::endl; // (5, 3) means index five and two character long.
    cout << conversation.substr(10, 4) << std::endl;
    cout << conversation.find_first_of("art") << std::endl;

    
}

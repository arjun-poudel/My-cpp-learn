// Escape sequence are special character that can be used as string or character.
// there are certain characters that get interpreted rather then just printed
// \t , \b are examples of escape sequence.
// \t says we want to do something rather; then just print \t
#include <iostream>
#include <string>
using std::cout;
using std::cin;
int main()
{
    cout << "Hellow\tThere";
    cout << "Mero\bBhai";
    cout << "Jatho\nKeto";
    cout << "Bhenubhupal\vAiar";
    cout << "Mutta\aSwami";
    cout << "Chenna\0Swami";
    cout << "Atta\"Pattu";
    cout << "Shrini\'Wasana";
}
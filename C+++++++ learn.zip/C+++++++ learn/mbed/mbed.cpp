#include "mbed.h"

// Reuse initialization code from the mbed library
DigitalOut led1(LED1); // P1_18

int main() 
{
    unsigned int mask_pin18 = 1 << 18;
    
    volatile unsigned int *port1_set = (unsigned int *)0x2009C038;
    volatile unsigned int *port1_clr = (unsigned int *)0x2009C03C;
    
    while (true) {
        *port1_set |= mask_pin18;
        wait(0.5);
        
        *port1_clr |= mask_pin18;
        wait(0.5);
    }
}

typedef struct 
{
    __IO uint32_t FIODIR;
    uint32_t RESERVED0[3];
    __IO uint32_t FIOMASK;
    __IO uint32_t FIOPIN;
    __IO uint32_t FIOSET;
    __O  uint32_t FIOCLR;
} LPC_GPIO_TypeDef;

#define LPC_GPIO_BASE   (0x2009C000UL)

#define LPC_GPIO0       ((LPC_GPIO_TypeDef *) (LPC_GPIO_BASE + 0x00000))
#define LPC_GPIO1       ((LPC_GPIO_TypeDef *) (LPC_GPIO_BASE + 0x00020))
#define LPC_GPIO2       ((LPC_GPIO_TypeDef *) (LPC_GPIO_BASE + 0x00040))
#define LPC_GPIO3       ((LPC_GPIO_TypeDef *) (LPC_GPIO_BASE + 0x00060))
#define LPC_GPIO4       ((LPC_GPIO_TypeDef *) (LPC_GPIO_BASE + 0x00080))

FIODIR   :  4 bytes
RESERVED0: 12 bytes
FIOMASK  :  4 bytes
FIOPIN   :  4 bytes
FIOSET   :  4 bytes
FIOCLR   :  4 bytes
tot      : 32 bytes = 0x20 bytes
#include<iostream>
using namespace std;

class Employee
{
public:   // it is by default private so we mention public to solve it. 
    string Name;
    string Company;
    int Age;
    void IntroduceYourself()
    {
        cout << "Name:- " << Name << endl;
        cout << "Company:- " << Company << endl;
        cout << "Age:- " << Age << endl;
    }
    Employee(string name, string company, int age) // creating constructors
    {
        Name = name;
        Company = company;
        Age = age;
    }
};
int main()
{
    Employee employee1 = Employee("Mike", "Nokia", 33);
    /*
    employee1.Name = "Mike";
    employee1.Company = "Nokia";
    employee1.Age = 33;
    */
    employee1.IntroduceYourself();
    
    Employee employee2 = Employee("John", "Google", 28);
    /*
    employee2.Name = "John";
    employee2.Company = "Google";
    employee2.Age = 28;
    */
    employee2.IntroduceYourself();

    Employee employee3 = Employee("Riya", "Microsoft", 30);
    employee3.IntroduceYourself();

}
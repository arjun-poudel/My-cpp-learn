#include<iostream>
using namespace std;
class AbstractEmployee
{
    virtual void AskForPromotion() = 0;
};
class Employee:AbstractEmployee
{
private:
    string Company;
    int Age;
protected:
    string Name;
public: 
    void setName(string name)
    {
        Name = name;
    }
    string getName()
    {
        return Name;
    }
    void setCompany(string company)
    {
        Company = company;
    }
    string getCompany()
    {
        return Company;
    }
    void setAge(int age)
    {
        if(age >= 18)
        Age = age;
    }
    int getAge()
    {
        return Age;
    }
    void IntroduceYourself()
    {
        cout << "Name:- " << Name << endl;
        cout << "Company:- " << Company << endl;
        cout << "Age:- " << Age << endl;
    }
    Employee(string name, string company, int age) // creating constructors
    {
        Name = name;
        Company = company;
        Age = age;
    }
    void AskForPromotion()
    {
        if(Age > 30)
        cout << Name << " got promoted!! " << endl;
        else
            cout << Name << " Sorry for time" << endl;
    }
};
class Developer: public Employee // this Developer class have all the above properties that Employee has
{
public:
    string FavPrLanguage;
    Developer(string name, string company, int age, string language) // creating constroctor for developer class
        :Employee(name, company, age)
        {
            FavPrLanguage = language;
        }
        void FixBug()
        {
            cout << Name << " fixed bug using " << FavPrLanguage << endl;
        }
};
class Teacher: public Employee
{
public:
    string Subject;
    void PrepareLesson()
    {
        cout << Name << " is preparing " << " the lesson " << endl;
    }
    Teacher(string name, string company, int age, string subject)
        :Employee(name, company, age)
        {
            Subject = subject;
        }
};
int main()
{
    Developer d = Developer("Mike", "Nokia", 32, "C++");
    d.FixBug();
    d.AskForPromotion();

    Teacher t = Teacher("jack", "Galaxy Boarding", 35, "History");
    t.PrepareLesson();
    t.AskForPromotion();
    /*
    Employee employee1 = Employee("Mike", "Nokia", 33);
    Employee employee2 = Employee("John", "Google", 28);
    Employee employee3 = Employee("Riya", "Microsoft", 30);
    employee1.AskForPromotion();
    employee2.AskForPromotion();
    employee3.AskForPromotion();
    employee1.IntroduceYourself();
    */
}
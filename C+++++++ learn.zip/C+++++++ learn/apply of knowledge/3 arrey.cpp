#include<iostream>
#include<string>
using namespace std;


int main()
{
    /*
    int guesses[] = {19, 13, 15, 47, 12, 10, 57};
    cout << guesses[3] << endl;
    guesses[3] = 200;
    cout << guesses[3] << endl;
    return 0;
    */
   /*
   int guesses[25];
   guesses[0] = 10;
   cin >> guesses[0]; // yo garda counsole output ma 4th number ma kun number xa lekhne
   cout << guesses[0] << endl;
   */

   int guesses[10] = { 13, 43, 45, 23, 45};
   // total number of elements is 5 but the out put is 20
   // because it takes in bites so 4 bites per each 4*5=20
   // to get actual size we divide it by 4 ie the size in bites of one elements
   // we do this by  / sizeof(guesses[0]);
   int size = sizeof(guesses) / sizeof(guesses[1]);
   int num_elements = 4; // yesto garna le jati size bhae ni kati ota out put garne determine garxa
   // jaslai for loop ma rakhnu parne hunxa i sita
   cout << size << endl;
   for(int i = 0; i < num_elements; i++)
   {
        cout << guesses[i] << "\t";
   }
   return 0;
}
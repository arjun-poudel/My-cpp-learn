#include <iostream>
#include <string>
#include <cstdlib> // for random number number we need 
#include <ctime> // both cstandered library and ctime
using namespace std;

void print_array(int array[], int count)
{
    for(int i = 0; i < count; i++)
    {
        cout << array[i] << "\t";
    } 
}

void play_game()
{
    int guesses[250];
    int guess_count = 0;

    int random = rand() & 251; // see tutoriol for random number
    cout << random << endl;
    cout << "Guess a number: ";
    while(true)
    {
        int guess;
        cin >> guess;
        guesses[guess_count++] = guess;
        // guess_count++; // mathi ++ nagare par sep statment ma garne
        if(guess == random)
        {
            cout << "** YOU WIN **\n";
            break;
        } else if (guess < random)
        {
            cout << "Sano bhayo solta\n";
        } else
        {
            cout << "Thulo bhayo solta\n";
        }
    }
    print_array(guesses, guess_count);
}
int main()
{
    srand(time(NULL));
    int choice;
    do
    {
        cout << "0. Quit" << endl << "1. Play Game\n";
        cin >> choice;
        switch(choice)
        {
            case 0:
                cout << "Thanx for nothing!!!\n";
                return 0;
            case 1:
                play_game();
                break;    
        }
    }
    while(choice != 0);
    
}
#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main()
{
    double amount, balance = 975.67;
    int choice;
    cout << fixed << setprecision(2);
    do
    {
        cout << "€€€€€ ATM Machine €€€€€\n";
        cout << "1. View the balance\n";
        cout << "2. Deposit\n";
        cout << "3. Withdrawal\n";
        cout << "4. Quit\n";
        cout << "\nEnter your selection: ";
        cin >> choice;
        switch (choice)
        {
            case 1:    
                cout << "Your balace is : &" <<balance << endl;
                break; 
            case 2:
                cout << "How much is the deposit?";
                cin >> amount;
                balance += amount;
                break;
            case 3:
                cout << "How much you want to withdraw?";
                cin >> amount;
                if(balance - amount >= 0)
                   balance -= amount;
                else
                    cout << "Sorry you dont have enough money\n";
                    break;  
             case 4:
                 cout << "**GOOD BYE**\n";
                 break;
            default:
                     cout << "Invalid Selection. Try again\n";       
        }
    }
    while(choice !=4);
}
#include <iostream>
#include <string>
#include<limits>
using namespace std;
void print_array(int array[], int size)
{
    for(int i = 0; i < size; i++)
    {
         cout << array[i] << "\t";
    }
    cout << endl;
}
int main()
{
    const int SIZE = 100;
    int guesses[SIZE];
    int count = 0;
    for(int i = 0; i < SIZE; i++)
    {
        if(cin >> guesses[i]) // we put if statement if SIZE is bigger n we want to stop in some point
        {
            count++;
            //input worked
        }   
        else
        {
            //invalid character
            break;
        }
    }
    print_array(guesses, count);
    cin.clear();
    // cin.ignore(10000, '\n');
    cin.ignore(numeric_limits < streamsize >::max(), '\n');
    string test;
    cin >> test;
    cout << test << endl;

    return 0;
}
#include <iostream>
#include <string>
using namespace std;

void print_array(int array[], int size)
{
   for(int i = 0; i < size; i++)
   {
        cout << array[i] << "\t";
   }
   cout << endl;
}

int main()
{
   int guesses[100]; // = {12, 14, 18, 28};
   int size = sizeof(guesses) / sizeof(int);
   print_array(guesses, 100);

   /*
   int size = sizeof(guesses) / sizeof(guesses[1]);
   int num_elements = 4; // yesto garna le jati size bhae ni kati ota out put garne determine garxa
   // jaslai for loop ma rakhnu parne hunxa i sita
   cout << size << endl;
   for(int i = 0; i < num_elements; i++)
   {
        cout << guesses[i] << "\t";
   }
   */
   return 0;
}

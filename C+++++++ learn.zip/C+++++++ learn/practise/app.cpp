#include <iostream>
#include <queue>
using namespace std;
int main()
{
    return 0;
}
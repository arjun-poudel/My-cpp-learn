#include <iostream>
#include <vector>
class User
{
    std::string status = "Silver";
    public:
        std::string first_name;
        std::string last_name;
        std::string get_status()
        {
            return status;
        }
};
int add_user_if_not_exists(std::vector<User> &users, User user)
{
    for(int i = 0; i < users.size(); i++)
    {
        if(users[i].first_name == user.first_name &&
            users[i].last_name == user.last_name)
        {
            return i;
        }
    }    
    users.push_back(user);
    return users.size() - 1;
}        
int main()
{
    std::vector<User> users;
    User user1, user2, user3;
    user1.first_name = "John";
    user1.last_name = "Jackson";
    user2.first_name = "laxman";
    user2.last_name = "Poudel";
    user3.first_name = "Arjun";
    user3.last_name = "Poudel";
    users.push_back(user1);
    users.push_back(user2);
    users.push_back(user3);
    User user;
    user.first_name = "Jacob";
    user.last_name = "Herliana";
    std::cout << add_user_if_not_exists(users, user) << std::endl;
    std::cout << users.size() << std::endl;
    return 0;
}
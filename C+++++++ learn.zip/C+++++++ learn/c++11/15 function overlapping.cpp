#include <iostream>
#include <string>
void swap(int a, int b)
{
    int temp = a;
    a = b;
    b = temp;
    std::cout << "a: " << a << "\tb: " << b << "\n";
}
void swap(std::string &a, std::string &b)
{
    std::string temp = a;
    a = b;
    b = temp;
}
int main()
{
    int a = 10;
    int b = 20;
    swap(a, b);
    std::string first_name = "Arjun";
    std::string last_name = "Poudel";
    swap(first_name, last_name);
    std::cout << first_name << " " << last_name << std::endl;
    std::cout << "a: " << a << "\tb: " << b << "\n";
    return 0;
}
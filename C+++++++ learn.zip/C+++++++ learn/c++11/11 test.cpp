#include <iostream>
double squared(double x)
{
    return x * x;
}
int main()
{
    if(squared(6) == 36)
    {
        std::cout << "test passed\n";
    }else
    {
        std::cout << "test failed\n";
    }
    return 0;
}
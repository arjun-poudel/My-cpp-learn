#include <iostream>
#include <string>
#include <cstdlib>  
#include <ctime> 
#include <vector>
#include <array>
using namespace std;
void print_array(std::array<int, 251> array, int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << array[i] << "\t";
    } 
}
void play_game()
{
    std::array<int, 251> guesses;
    int count = 0;
    int random = rand() & 251;
    cout << random << endl;
    cout << "Guess a number: ";
    while(true)
    {
        int guess;
        cin >> guess;

        guesses[count++] = guess;
        if(guess == random)
        {
            cout << "** YOU WIN **\n";
            break;
        } else if (guess < random)
        {
            cout << "Sano bhayo solta\n";
        } else
        {
            cout << "Thulo bhayo solta\n";
        }
    }
    print_array(guesses, count);
}
int main()
{
    srand(time(NULL));
    int choice;
    do
    {
        cout << "0. Quit" << endl << "1. Play Game\n";
        cin >> choice;
        switch(choice)
        {
            case 0:
                cout << "Thanx for nothing!!!\n";
                return 0;
            case 1:
                play_game();
                break;    
        }
    }
    while(choice != 0);
}
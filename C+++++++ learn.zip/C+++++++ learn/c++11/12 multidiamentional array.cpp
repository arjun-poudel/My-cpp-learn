#include <iostream>
#include <vector>
int main()
{
    /*
    // this is only working in online compiler
    std::vector<std::vector<int>> grades =
    {   {1, 2, 3}, 
        {4, 5, 6}, 
        {7, 8, 9}
    };
    */
    int grades[][3] = {
        {1, 2, 3}, 
        {4, 5, 6}, 
        {7, 8, 9}};
    for(int r = 0; r < 6; r++ ) // r for row and c for column
    {
        for(int c = 0; c < 3; c++)
        {
              std::cout << grades[r][c] << "\t";
        }
        std::cout << "\n";
    }

    return 0;
}
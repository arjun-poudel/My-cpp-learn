#include <iostream>
#include <vector>

int main()
{
    std::vector<int> data;
    for (int i = 1; i <= 8; i++)
    data.push_back(i);
    std::cout << data[4] << std::endl;
    std::cout << data[data.size() - 1] << std::endl;
    data.pop_back();
    std::cout << data.size() << std::endl;
}

/*
#include <iostream>
#include <vector>

int main()
{
    std::vector<int> data = {1, 2, 3, 4, 5};
    data.push_back(12);
    std::cout << data[4] << std::endl;
    std::cout << data[data.size() - 1] << std::endl;
    data.pop_back();
    std::cout << data.size() << std::endl;
}
*/
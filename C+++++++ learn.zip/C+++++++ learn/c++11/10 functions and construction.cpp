#include <iostream>
#include <string>
#include <cstdlib>  
#include <ctime> 
#include <vector>
#include <array>
#include <fstream>
using namespace std;
void save_score(int count)
{
    std::ifstream input("best_score.txt");
    if(!input.is_open())
    {
        std::cout << "Unable to read file\n";
        return;
    }
    int best_score;
    input >> best_score;
    std::ofstream output("best_score.txt");
    if(!output.is_open())
    {
        std::cout << "Unable to read file\n";
        return;
    }
    if(count < best_score)
    {
        output << count;
    }
    else
    {
        output << best_score;
    }
}
void print_vector(std::vector<int> vector)
{
    for(int i = 0; i < vector.size(); i++)
    {
        cout << vector[i] << "\t";
    } 
}
void play_game()
{
    std::vector<int> guesses;
    int count = 0;
    int random = rand() & 251;
    cout << random << endl;
    cout << "Guess a number: ";
    while(true)
    {
        int guess;
        cin >> guess;
        count++;
        guesses.push_back(guess);
        if(guess == random)
        {
            cout << "** YOU WIN **\n";
            break;
        } else if (guess < random)
        {
            cout << "Sano bhayo solta\n";
        } else
        {
            cout << "Thulo bhayo solta\n";
        }
    }
    save_score(count);
    print_vector(guesses);
}
int main()
{
    srand(time(NULL));
    int choice;
    do
    {
        cout << "0. Quit" << endl << "1. Play Game\n";
        cin >> choice;
        switch(choice)
        {
            case 0:
                cout << "Thanx for nothing!!!\n";
                return 0;
            case 1:
                play_game();
                break;    
        }
    }
    while(choice != 0);
}
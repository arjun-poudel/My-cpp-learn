#include <iostream>
#include <vector>
#include <array>
using namespace std;

void print_array(array<int, 20> data, int size)
{
    data.push_back(12);
    for(int i =0; i < size; i++)
    {
        cout << data[i] << "\t";
    }
    cout << "\n";
}

int main()
{
    array<int, 20> data ={13, 45, 87, 67, 89, 87, 67};
    print_array(data, 5);
}


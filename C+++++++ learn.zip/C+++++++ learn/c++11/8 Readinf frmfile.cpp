#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    /*
    ifstream file ("tacos.txt");
    vector<string> names;
    string input;
    while(file >> input)
    {
        names.push_back(input);
    }
    for(string name : names)
    {
        cout << name << endl;
    }
    */

    ifstream file ("tacos.txt");
    string line;
    getline(file, line);
    cout << line << "\n";
    return 0;

}
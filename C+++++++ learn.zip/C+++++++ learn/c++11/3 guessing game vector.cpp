#include <iostream>
#include <string>
#include <cstdlib> // for random number number we need 
#include <ctime> // both cstandered library and ctime
#include <vector>
using namespace std;

void print_vector(std::vector<int> vector)
{
    for(int i = 0; i < vector.size(); i++)
    {
        cout << vector[i] << "\t";
    } 
}

void play_game()
{
    std::vector<int> guesses;
    int guess_count = 0;

    int random = rand() & 251; // see tutoriol for random number
    cout << random << endl;
    cout << "Guess a number: ";
    while(true)
    {
        int guess;
        cin >> guess;
        guesses.push_back(guess);
        // guess_count++; // mathi ++ nagare par sep statment ma garne
        if(guess == random)
        {
            cout << "** YOU WIN **\n";
            break;
        } else if (guess < random)
        {
            cout << "Sano bhayo solta\n";
        } else
        {
            cout << "Thulo bhayo solta\n";
        }
    }
    print_vector(guesses);
}
int main()
{
    srand(time(NULL));
    int choice;
    do
    {
        cout << "0. Quit" << endl << "1. Play Game\n";
        cin >> choice;
        switch(choice)
        {
            case 0:
                cout << "Thanx for nothing!!!\n";
                return 0;
            case 1:
                play_game();
                break;    
        }
    }
    while(choice != 0);
    
}
#include <iostream>
#include <vector>
#include <array>
using namespace std;
/*
void test(int data[])
{
    for(int n : data)
    {
        cout << n << "\t";
    }
}
*/
int main()
{
    // int data[] = {1, 2, 3, 4, 5, 6}; // array
    // vector<int> data = {1, 2, 3, 4, 5, 6}; // vector
    array<int, 10 > data = {1, 2, 3, 4, 5, 6}; // array

    for(int n : data)
    {
        cout << n << "\t";
    }
    /*
    for(int i = 0; i < 6; i++)
    {
        cout << data[i] << "\t";
    }
    */
    cout << "\n";    

}
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    string filename;
    cin >> filename;
    ofstream file (filename.c_str(), ios::app);

    if(file.is_open())
    {
        cout << "sucess n00b\n";
    }
    vector<std::string> names;
    // file << "hey gajjab bhai raa xa";
    // file.open("hello.txt");
    names.push_back("Caleb");
    names.push_back("Arjun");
    names.push_back("Lina");
    names.push_back("Laxman");
    names.push_back("Aaral");

    for(string name : names)
    {
        file << name << endl;
    }
    file.close(); // it closes it self but to be more specific we can use.close
    return 0;
}